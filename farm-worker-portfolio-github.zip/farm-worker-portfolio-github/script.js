function printResume() {
  window.print();
}
